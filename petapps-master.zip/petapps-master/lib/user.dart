class Users{
  int cedula;
  String nombre;
  String email;
  int phone;
  String address;
  String bornDate;
  String city;
  Users({
    required this.cedula,
    required this.nombre,
    required this.email,
    required this.phone,
    required this.address,
    required this.bornDate,
    required this.city
  });
}