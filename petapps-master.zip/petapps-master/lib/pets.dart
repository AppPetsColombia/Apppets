class Pets {
  String nombre;
  String tipoMascota;
  int edad;
  String tipoEdad;
  String raza;
  String address;
  int phone;
  String departament;
  String city;
  String url;
  String email;
  String motivo;
  String salud;
  String id;


  Pets({
      required this.nombre,
      required this.tipoMascota,
      required this.edad,
      required this.tipoEdad,
      required this.raza,
      required this.address,
      required this.phone,
      required this.departament,
      required this.city,
      required this.url,
      required this.email,
      required this.motivo,
      required this.salud,
      required this.id
  });
  
}