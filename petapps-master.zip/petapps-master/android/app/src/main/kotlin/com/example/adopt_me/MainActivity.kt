package com.example.adopt_me

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
